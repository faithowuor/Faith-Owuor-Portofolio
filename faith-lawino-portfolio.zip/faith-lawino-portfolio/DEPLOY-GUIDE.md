# How to Deploy Your Portfolio to GitHub Pages

## Step 1 — Create a GitHub Account
Go to https://github.com and sign up (free).

## Step 2 — Create a New Repository
1. Click the "+" icon at top right → "New repository"
2. Name it: `faith-lawino-portfolio`
3. Set to Public
4. Do NOT add README (we have one already)
5. Click "Create repository"

## Step 3 — Upload Your Files
**Option A — Upload via browser (easiest):**
1. On your new repo page, click "uploading an existing file"
2. Drag and drop ALL your files and folders
3. Important: Upload the folders too, not just the index.html
4. Scroll down, click "Commit changes"

**Option B — Using GitHub Desktop App:**
1. Download GitHub Desktop from desktop.github.com
2. Clone your new repo
3. Copy all portfolio files into the cloned folder
4. Commit and push

## Step 4 — Enable GitHub Pages
1. Go to your repository
2. Click "Settings" tab
3. Scroll to "Pages" in the left sidebar
4. Under "Source": select "Deploy from a branch"
5. Branch: main | Folder: / (root)
6. Click Save

## Step 5 — Wait 2-3 Minutes
Your site will be live at:
https://[your-github-username].github.io/faith-lawino-portfolio/

## Adding Your Own Writing Samples (PDFs)
1. Export your Google Doc as PDF
2. Upload it to the `writing-samples/` folder in GitHub
3. In `writing-samples/index.html`, add:
   ```html
   <a href="your-file-name.pdf" target="_blank">Read Full Article</a>
   ```

## Updating Your Portfolio
- Go to github.com → your repo
- Click the file you want to edit
- Click the pencil icon to edit
- Make changes → Commit
- Site updates automatically within 1-2 minutes
